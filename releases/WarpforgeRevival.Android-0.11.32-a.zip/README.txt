Warpforge Revival mod for Android - version 0.11.32-a
=====================================================

This is the mod only. It needs the Android game patched with the mod loader
first - see the instructions at
    https://github.com/silentanarchist/warpforge-revival-mod-android

Putting the mod on the phone
----------------------------
Either:
  a) copy WarpforgeRevival.Android.dll into the "mods" folder of the patcher
     and run "3 - put mod on phone.bat" (phone connected by USB), or
  b) copy WarpforgeRevival.Android.dll on the phone itself into
        MelonLoader/com.Everguild.WarhammerWarpforge/Mods/
     (internal storage) with a file manager.

Start the game. If the server asks for an account, a sign-in window appears:
use your account from the server's website (or create one). The phone
remembers the sign-in. On a phone the keyboard's check mark sends a chat
message. From then on the mod updates itself when the server
has a newer version.

To play as someone else on this phone, use Sign out in Settings > Account. It
signs out this phone only; your account keeps its progress.

Forgotten your password? Make a recovery code on the website's Profile page
while you still know it, and keep the file it downloads. "Forgot your
password?" on the website's sign-in page takes the code and a new password.

Black screen or coloured blocks after signing in?
-------------------------------------------------
Seen on a Pixel 6 Pro and not solved yet. Try the game's own
Settings > Graphics > Extended compatibility, then restart the game. If it
still happens, leave the game on the black screen, run "0 - get phone logs.bat"
from the patcher while it is still running, and send the folder it makes.

The mod's version is shown next to the game's in Settings > General.
Android builds end in -a, Windows builds in -w.

Matches against other players are encrypted when the server offers it, like
everything else the mod sends.

If something goes wrong
-----------------------
Run "0 - get phone logs.bat" from the patcher and send the folder it makes.
